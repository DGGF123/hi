**Discord server: https://discord.gg/K5xUbuDqmG**

# Blooket-Hack
All of the cheats are based on a game mode.

**All these bookmarklets are also at: https://schoolcheats.net/blooket**

# Video Tutorial
https://user-images.githubusercontent.com/73669084/142779206-6cef86be-b2a5-4958-8637-cb6bde2a42da.mp4


# Bookmarklet tutorial:
https://streamable.com/t4u7i7

1. Make a bookmark (the star on the right side of the url bar if you are using chrome)
2. Click on more at the bottom left corner
3. Delete everything in the url box
4. Type `javascript:`
5. Paste in the code
