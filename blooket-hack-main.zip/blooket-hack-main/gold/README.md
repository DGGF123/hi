**Discord server: https://discord.gg/K5xUbuDqmG**

**These bookmarklets are also on: https://schoolcheats.net/blooket**

# gold

This cheat only works in gold game mode!

# chest-ESP.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjEzL2dvbGRDaGVzdEVTUC5qcw==')).then((res) => res.text().then((t) => eval(t)))
```

# getGold.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch(atob('aHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vc2Nob29sLWNoZWF0cy9yYXcvdXBsb2FkL3YxNjM3NDUyMjEzL2dvbGRHZXRHb2xkLmpz')).then((res) => res.text().then((t) => eval(t)))
```
